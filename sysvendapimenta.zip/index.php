<?php
require (dirname(__FILE__). "/controller/BeanShopping.class.php");
require (dirname(__FILE__)."/controller/BeanUsuario.class.php");
//BeanUsuario::autentica();
?>
<a href="./controller/BeanUsuario.class.php/autentica/?usuario= Wilton">Vai</a>